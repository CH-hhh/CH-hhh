#pragma once
#include<iostream>
using namespace std;

#include"Worker.h"

class Employee :public Worker
{
public:
	Employee(int id, string name, int did);

	virtual void Show_Info();

	virtual string GetDeptName();
};
