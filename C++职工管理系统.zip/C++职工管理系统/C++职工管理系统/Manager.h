#pragma once

using namespace std;

#include"Worker.h"

class Manager :public Worker
{
public:
	Manager(int id, string name, int did);

	virtual void Show_Info();

	virtual string GetDeptName();
};

