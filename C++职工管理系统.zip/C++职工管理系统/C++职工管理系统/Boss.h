#pragma once

#include"Worker.hpp"

using namespace std;


class Boss :public Worker
{
public:
	Boss(int id, string name, int did);

	virtual void const Show_Info();

	virtual const string GetDeptName() const;
};


